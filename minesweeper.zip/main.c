#include<stdio.h>
#include "acllib.h"
#include<time.h>
#include<stdlib.h>
#include<math.h>
#define GAP 30
#define NUM 20
#define POSX 10
#define POSY 50
//const int NUM=30;

ACL_Image img1;//mine
ACL_Image img2;//background
//ACL_Image img3;

ACL_Image img3;//flag
ACL_Image img4;//question mark

ACL_Image img11;
ACL_Image img12;
ACL_Image img13;
ACL_Image img14;
ACL_Image img15;
ACL_Image img16;
ACL_Image img17;
ACL_Image img18;
ACL_Image img19;

ACL_Image img_zero;
int ismine[NUM][NUM]={0};//-1���ף�1-8��������0����Χ��û���� 

int found_mine=0; 
int is_shown[NUM][NUM]={0};

void cal_mine(int i,int j)
{
	if(i<0||j<0||i>20||j>20)
	{
		return;
	}
	if(ismine[i][j]==-1)
	{
		return;
	}
	else
	{
		ismine[i][j]++;
		
	}
}


int numofmines=0;

int iszero[NUM][NUM]={0};



void find_zero(int x,int y)
{
	if(x<0||x>=NUM||y<0||y>=NUM)return;
	if(iszero[x][y]==1)return;
	if(ismine[x][y]!=-1&&ismine!=0)
	{
		beginPaint();
		loadImage("1.bmp",&img11);
		loadImage("2.bmp",&img12);
		loadImage("3.bmp",&img13);
		loadImage("4.bmp",&img14);
		loadImage("5.bmp",&img15);
		loadImage("6.bmp",&img16);
		loadImage("7.bmp",&img17);
		loadImage("8.bmp",&img18);
		loadImage("9.bmp",&img19);
		int a=x,b=y;
		switch(ismine[a][b])
		{
			case 1:putImage(&img11,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
			case 2:putImage(&img12,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
			case 3:putImage(&img13,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
			case 4:putImage(&img14,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
			case 5:putImage(&img15,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
			case 6:putImage(&img16,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
			case 7:putImage(&img17,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
			case 8:putImage(&img18,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
			case 9:putImage(&img19,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
		}
		endPaint();
	}
	if(ismine[x][y]==0)
	{
		iszero[x][y]=1;
		beginPaint();
		loadImage("zero.jpg",&img_zero);
		putImage(&img_zero,POSX+GAP*x,POSY+GAP*y);
		is_shown[x][y]=1;
		endPaint();
		//��
		find_zero(x,y-1); 
		//�� 
		find_zero(x-1,y);
		//�� 
		find_zero(x+1,y);
		//�� 
		find_zero(x,y+1);
	}
	if((iszero[x+1][y]==1||ismine[x+1][y]!=-1)&&(iszero[x][y+1]==1||ismine[x][y+1]!=-1)&&(iszero[x][y-1]==1||ismine[x][y-1]==-1)&&(iszero[x-1][y]==1||ismine[x-1][y]!=-1))return;
	
	
	
}

int right_key=0;
void calrightkey(void)
{
	if(right_key<2)right_key++;
	else
	{
		if(right_key==2)right_key=0;
	}
}

void rightkey(int a,int b)
{
	beginPaint();
	loadImage("flag.bmp",&img3);
	loadImage("qsmark.jpg",&img4);
	loadImage("background.jpg",&img2);
	switch(right_key)
	{
		case 0:putImage(&img2,POSX+GAP*a+1,POSY+GAP*b+1);break;
		case 1:putImage(&img3,POSX+GAP*a+1,POSY+GAP*b+1);break;
		case 2:putImage(&img4,POSX+GAP*a+1,POSY+GAP*b+1);break;
	}
	endPaint();
	return;
}
int isfailed=0;

void EVENT1(int x,int y,int bt,int event)
{
	if(isfailed)return;
	int left_sq=0;
	for(int i=0; i<NUM; i++)
	{
		for(int j=0; j<NUM; j++)
		{
			if(is_shown[i][j])
			{
				left_sq++;
			}
		}
	}
	if((left_sq+numofmines)==NUM*NUM)
	{
		printf("You win!");
		return;
	}
	
//	//˫�� 
//	if(event==BUTTON_DOUBLECLICK&&bt==LEFT_BUTTON)
//	{
//		int a,b;
//		a=(x-POSX)/GAP;
//		b=(y-POSY)/GAP;
//		for(int i=a-1; i<=a+1; i++)
//		{
//			for(int j=b-1; j<=b+1; j++)
//			{
//				if(ismine[i][j]!=-1)
//				{
//					beginPaint();
//					loadImage("1.bmp",&img11);
//					loadImage("2.bmp",&img12);
//					loadImage("3.bmp",&img13);
//					loadImage("4.bmp",&img14);
//					loadImage("5.bmp",&img15);
//					loadImage("6.bmp",&img16);
//					loadImage("7.bmp",&img17);
//					loadImage("8.bmp",&img18);
//					loadImage("9.bmp",&img19);
//					switch(ismine[a][b])
//					{
//						case 1:putImage(&img11,POSX+GAP*a,POSY+GAP*b);is_shown[a][b]=1;break;
//						case 2:putImage(&img12,POSX+GAP*a,POSY+GAP*b);is_shown[a][b]=1;break;
//						case 3:putImage(&img13,POSX+GAP*a,POSY+GAP*b);is_shown[a][b]=1;break;
//						case 4:putImage(&img14,POSX+GAP*a,POSY+GAP*b);is_shown[a][b]=1;break;
//						case 5:putImage(&img15,POSX+GAP*a,POSY+GAP*b);is_shown[a][b]=1;break;
//						case 6:putImage(&img16,POSX+GAP*a,POSY+GAP*b);is_shown[a][b]=1;break;
//						case 7:putImage(&img17,POSX+GAP*a,POSY+GAP*b);is_shown[a][b]=1;break;
//						case 8:putImage(&img18,POSX+GAP*a,POSY+GAP*b);is_shown[a][b]=1;break;
//						case 9:putImage(&img19,POSX+GAP*a,POSY+GAP*b);is_shown[a][b]=1;break;
//					}
//					endPaint();
//				}
//			}
//		}
//	}
	
	
	
	if(event!=BUTTON_DOWN)return;
	if(bt==LEFT_BUTTON)
	{
		//�ж���(a,b)������
		int a,b=0;
		a=(x-POSX)/GAP;
		b=(y-POSY)/GAP;
		if(a>=0&&b>=0)
		{
			if(ismine[a][b]==-1)
			{
				beginPaint();
				loadImage("mine.jpg",&img1);
				putImage(&img1,POSX+GAP*a,POSY+GAP*b);
				endPaint();
				printf("You failed!Try it again!\n");
				isfailed=1;
				return;
			}
			else
			{
				if(ismine[a][b]!=-1&&ismine[a][b]!=0)
				{
					beginPaint();
					loadImage("1.bmp",&img11);
					loadImage("2.bmp",&img12);
					loadImage("3.bmp",&img13);
					loadImage("4.bmp",&img14);
					loadImage("5.bmp",&img15);
					loadImage("6.bmp",&img16);
					loadImage("7.bmp",&img17);
					loadImage("8.bmp",&img18);
					loadImage("9.bmp",&img19);
					switch(ismine[a][b])
					{
						case 1:putImage(&img11,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
						case 2:putImage(&img12,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
						case 3:putImage(&img13,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
						case 4:putImage(&img14,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
						case 5:putImage(&img15,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
						case 6:putImage(&img16,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
						case 7:putImage(&img17,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
						case 8:putImage(&img18,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
						case 9:putImage(&img19,POSX+GAP*a+1,POSY+GAP*b+1);is_shown[a][b]=1;break;
					}
					endPaint();
				}
				if(ismine[a][b]==0)//���� 
				{
					find_zero(a,b);
//					for(int i=0; i<NUM; i++)
//					{
//						for(int j=0; j<NUM; j++)
//						{
//							printf("%d ",iszero[i][j]);
//						}
//						printf("\n");
//					}
				}
			}
		
			
		} 
	}
	if(bt==3)
	{
		int a,b;
		a=(x-POSX)/GAP;
		b=(y-POSY)/GAP;
		calrightkey();
		rightkey(a,b);
	}
}
//main
int Setup()
{
	initWindow("Minesweeper v1.0",DEFAULT,DEFAULT,720,720);
	//���� 
	for(int i=0; i<=NUM; i++)
	{
		beginPaint();
		line(POSX+GAP*i,POSY,POSX+GAP*i,POSY+NUM*GAP);
		line(POSX,POSY+GAP*i,POSX+GAP*NUM,POSY+GAP*i);
		endPaint();
	}
	//���� 
	initConsole();
	printf("�������׵�����");
	scanf("%d",&numofmines);
	while(numofmines<=0)
	{
		printf("�������ݲ��Ϸ�");
		scanf("%d",numofmines);
	}
	//������
	beginPaint();
	loadImage("background.jpg",&img2);
	for(int i=0; i<NUM; i++)
	{
		for(int j=0; j<NUM; j++)
		{
			putImage(&img2,POSX+GAP*i+1,POSY+GAP*j+1);
		}
	}
	endPaint(); 
	int randnum=0;
	for(int i=0; i<numofmines; i++)
	{
		randoms:
		srand(i+randnum+time(NULL));
		int a=rand();
		a%=NUM;
		
		srand(3+i+time(NULL));
		int b=rand();
		b%=NUM;

		//����
		if(i==0)
		{
			ismine[a][b]=-1;//x//y	
		}
		else
		{
				if(ismine[a][b]!=-1)
				{
					ismine[a][b]=-1;
				}
				else 
				{
					randnum++;
					goto randoms;
				}
			
		}
//		printf("%d %d\n",a,b);
	}
//	printf("%d %d",a,b);
	
	//��̨����
	for(int i=0; i<NUM; i++)
	{
		for(int j=0; j<NUM; j++)
		{
			if(ismine[i][j]==-1)
			{
				cal_mine(i-1,j-1);
				cal_mine(i-1,j);
				cal_mine(i-1,j+1);
				cal_mine(i,j-1);
				cal_mine(i,j+1);
				cal_mine(i+1,j-1);
				cal_mine(i+1,j);
				cal_mine(i+1,j+1);	
			}
			
		}
	}
	for(int i=0; i<NUM; i++)
	{
		for(int j=0; j<NUM; j++)
		{
			printf("%d ",ismine[j][i]);
		}
		printf("\n");
	}
	
	//���ӻ�ǰ̨
	registerMouseEvent(EVENT1);
//	registerMouseEvent(testevent);
	return 0;
};
